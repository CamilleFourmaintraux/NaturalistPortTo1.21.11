# Naturalist — unofficial Fabric port to Minecraft 1.21.11

Personal, unofficial port of [Naturalist](https://github.com/crispytwig/Naturalist) by crispytwig / Starfish Studios (MIT license).
Not affiliated with the original authors. Not intended for redistribution.

## Build

Requirements: JDK 21, internet access (Gradle downloads Minecraft, Loom, Fabric API).

```bash
./gradlew build
```

The mod jar is written to `build/libs/naturalist-fabric-1.21.11-<version>.jar`
(ignore the `-sources` jar). Drop it in `mods/` together with Fabric API for 1.21.11.

Toolchain used here: Gradle 9.2.1 wrapper, `fabric-loom` 1.14-SNAPSHOT, Mojang mappings,
Fabric Loader 0.18.2+, Fabric API 0.141.6+1.21.11. If Gradle/Loom versions cause trouble,
copy the wrapper and Loom version from another working 1.21.11 Fabric project.

## How the port was made

The upstream repository has no 1.21.11 branch. It has `1.21.1-MultiLoader` (= 2.0.7, the jar this port
replaces) and `26.1.2-MultiLoader`. 26.1.2 already contains almost every API change made between 1.21.2
and 1.21.11, so this port starts from the **26.1.2 sources** and backports the 26.1-only changes to 1.21.11.

Only the Fabric side is kept (common + fabric merged into one Loom project). NeoForge was dropped.

### Java changes (26.1 → 1.21.11)

- Fabric API names: `FabricBrewingRecipeRegistryBuilder`, `ParticleFactoryRegistry`, `EntityModelLayerRegistry`.
- Block render layers are declared with `BlockRenderLayerMap` (26.x infers them from textures; 1.21.11 does not).
- `RenderTypes` renames: 26.1 `entityCutout` → 1.21.11 `entityCutoutNoCull`, 26.1 `entityCutoutCull` → 1.21.11 `entityCutout`.
- `PathType` constants: `FIRE_IN_NEIGHBOR`/`FIRE`/`DAMAGING_IN_NEIGHBOR`/`DAMAGING`/`ON_TOP_OF_POWDER_SNOW`
  → `DANGER_FIRE`/`DAMAGE_FIRE`/`DANGER_OTHER`/`DAMAGE_OTHER`/`DANGER_POWDER_SNOW`.
- `ItemStackTemplate` removed (item particles and the bug-net recipe use `ItemStack` again).
- `Recipe.assemble(input, registries)` and an anonymous `RecipeSerializer` implementation.
- `BlockTags.SUBSTRATE_OVERWORLD` → `BlockTags.DIRT`, `Level.getDefaultClockTime()` → `getDayTime()`.
- `Entity.is(TagKey)` → `entity.getType().is(TagKey)`.
- `DataComponents.DYE` → `DyeItem#getDyeColor()`; `Player.sendOverlayMessage` → `displayClientMessage(msg, true)`.
- `Entity.interact(player, hand, location)` → `interact(player, hand)`.
- Rendering: snail shell block entity and hippo jaw block rewritten for the 1.21.11 block model API;
  banner layer uses `MaterialSet` / `ModelBakery.BANNER_BASE`; elephant inventory screen uses `GuiGraphics`;
  camera state read through `GameRenderer.getLevelRenderState()`.
- Moved classes re-imported from their 1.21.11 packages (`CameraRenderState`, `BakedQuad`, `Material`, …).
- Mixins: targets checked against 1.21.11; parrot shoulder injection descriptor updated; NeoForge-only
  selectors removed from the advancement JSON mixin.

### Data and assets

- Entity predicates in loot tables: `minecraft:flags` / `minecraft:nbt` / `minecraft:entity_type`
  → `flags` / `nbt` / `type` (1.21.11 format).
- Vanilla item tags from 2.0.7 restored (`meat`, `cat_food`, `ocelot_food`, `piglin_food`, `axolotl_food`);
  the non-vanilla `is_meat` tag from 26.1.2 was removed.
- Pack format metadata set to 1.21.11 (resource 75, data 94).

### Removed

- Field Guide integration (no Field Guide release exists for 1.21.11).
- NeoForge loader module.

LambDynamicLights integration is kept (compile-only dependency on its 1.21.11 API, 4.9.1).

## Verification status

The port was statically checked (no Minecraft jar was available in the porting environment):
type-checked with `javac` against decompiled 1.21.11 sources, Fabric API 1.21.11 and library sources,
plus scripted checks of mixin targets, constants, data identifiers and asset references.
It has **not** been compiled with Loom or tested in game yet, so expect a few remaining compile errors
or runtime issues on the first build.

Content is based on the newest upstream code (26.1.2 branch), so small gameplay differences
from 2.0.7 are possible. Existing 1.21.1 worlds: back them up before loading them with this port.
