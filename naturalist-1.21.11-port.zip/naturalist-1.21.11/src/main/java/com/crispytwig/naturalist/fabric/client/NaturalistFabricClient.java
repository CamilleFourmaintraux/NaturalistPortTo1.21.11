package com.crispytwig.naturalist.fabric.client;

import com.crispytwig.naturalist.NaturalistClient;
import com.crispytwig.naturalist.NaturalistClientConfig;
import com.crispytwig.naturalist.fabric.config.FabricNaturalistClientConfig;
import com.crispytwig.naturalist.client.particle.CaptureNetSwingParticle;
import com.crispytwig.naturalist.registry.NaturalistParticleTypes;
import com.crispytwig.naturalist.registry.NaturalistRegistry;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.particle.v1.ParticleFactoryRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.BlockRenderLayerMap;
import net.fabricmc.fabric.api.client.rendering.v1.EntityModelLayerRegistry;
import net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry;
import net.minecraft.client.gui.screens.MenuScreens;
import net.minecraft.client.renderer.blockentity.BlockEntityRenderers;
import net.minecraft.client.renderer.chunk.ChunkSectionLayer;
import net.minecraft.client.renderer.item.properties.conditional.ConditionalItemModelProperties;

public class NaturalistFabricClient implements ClientModInitializer {
    @Override
    public void onInitializeClient() {
        FabricNaturalistClientConfig.load();
        NaturalistClientConfig.setGlowGoopTooltip(FabricNaturalistClientConfig::isGlowGoopTooltipEnabled);

        NaturalistClient.registerLayerDefinitions((location, definition) ->
                EntityModelLayerRegistry.registerModelLayer(location, definition::get));
        NaturalistClient.registerRenderers(EntityRendererRegistry::register);
        NaturalistClient.registerBlockEntityRenderers(BlockEntityRenderers::register);

        NaturalistClient.registerMenuScreens(MenuScreens::register);

        NaturalistClient.registerConditionalItemModelProperties(ConditionalItemModelProperties.ID_MAPPER::put);

        ParticleFactoryRegistry.getInstance().register(NaturalistParticleTypes.CAPTURE_NET_SWING.get(), CaptureNetSwingParticle.Provider::new);

        registerBlockRenderLayers();
    }

    /**
     * 26.x infers the chunk layer from block textures; 1.21.11 still needs it declared.
     */
    private static void registerBlockRenderLayers() {
        BlockRenderLayerMap.putBlocks(ChunkSectionLayer.CUTOUT,
                NaturalistRegistry.ORANGE_STARFISH.get(),
                NaturalistRegistry.PURPLE_STARFISH.get(),
                NaturalistRegistry.BLUE_STARFISH.get(),
                NaturalistRegistry.RED_STARFISH.get(),
                NaturalistRegistry.SNAIL_EGGS.get(),
                NaturalistRegistry.SNAIL_SHELL_BLOCK.get(),
                NaturalistRegistry.CHRYSALIS_BLOCK.get(),
                NaturalistRegistry.GLOW_GOOP_BLOCK.get(),
                NaturalistRegistry.ALLIGATOR_EGG.get(),
                NaturalistRegistry.OSTRICH_EGG.get(),
                NaturalistRegistry.TORTOISE_EGG.get(),
                NaturalistRegistry.PLUSH_BEAR.get());

        BlockRenderLayerMap.putBlocks(ChunkSectionLayer.TRANSLUCENT,
                NaturalistRegistry.AZURE_FROGLASS.get(),
                NaturalistRegistry.VERDANT_FROGLASS.get(),
                NaturalistRegistry.CRIMSON_FROGLASS.get(),
                NaturalistRegistry.AZURE_FROGLASS_PANE.get(),
                NaturalistRegistry.VERDANT_FROGLASS_PANE.get(),
                NaturalistRegistry.CRIMSON_FROGLASS_PANE.get());
    }
}
